"""RGB-only 建图验证 agent：随机探索并把每步 RGB 喂给 VGGT-SLAM。

该 agent 不读取深度、GPS、compass 或仿真器真值。episode 结束时保存
SLAM 轨迹和在线尺度诊断；ATE 等真值指标应由 benchmark evaluator 在
agent 边界之外计算。

运行（需先启动 mapping 服务端，见 scripts/run_mapping_server.sh）：

    python run_eval.py \
      --config hm3d_config.yaml \
      --agent agents.mapping_agent:MappingAgent \
      --goal-type description \
      --dataset-dir dataset_semantic \
      --scene-root /path/to/hm3d/val \
      --limit 1 --episode-limit 1 --max-steps 300
"""

import atexit
import json
import os
import time

import numpy as np

from benchmark_api import Action
from mapping.client import MappingClient
from mapping.scale_calibration import ScaleCalibrator
from runtime_paths import env_debug_path, run_debug_path

class MappingAgent:
    def __init__(self):
        self.client = MappingClient(
            host=os.environ.get("VGGT_SLAM_HOST", "127.0.0.1"),
            port=int(os.environ.get("VGGT_SLAM_PORT", "5555")),
        )
        self.output_dir = env_debug_path(
            "MAPPING_DEBUG_DIR", run_debug_path("agent"))
        os.makedirs(self.output_dir, exist_ok=True)
        self.episode_id = None
        self.rng = np.random.default_rng(0)
        self._last_visual = None
        self._last_motion_failed = False
        self._visual_stall_count = 0
        self.stuck_steps = 0
        self._server_busy = False
        self._last_feed_info = {}
        self._action_trace_path = env_debug_path(
            "NAV_ACTION_TRACE",
            os.path.join(self.output_dir, "action_trace.jsonl"))
        self._trace_write_warned = False
        self._episode_diag_warned = False
        self._frame_save_err = False
        self.calibrator = ScaleCalibrator(
            window=int(os.environ.get("MAPPING_SCALE_WINDOW", "20")))
        # NAV_ORACLE_GEOMETRY=1：离线消融钩——用 GT 位移（米）替换
        # "前进=0.25m" 假设做尺度标定。仅限实验分支的消融，严禁进入
        # RGB-only 主评测路径。
        self.oracle_geometry = os.environ.get(
            "NAV_ORACLE_GEOMETRY", "0") == "1"
        self._oracle_gt = []         # 每步的 GT 位置（米），无 gps 时为 None
        if self.oracle_geometry:
            print("=" * 70)
            print("[MappingAgent] !!! NAV_ORACLE_GEOMETRY=1 —— 正在使用仿真器 "
                  "GT 位姿做尺度标定（oracle 消融），结果不可用于主评测 !!!")
            print("=" * 70)
        atexit.register(self._finalize)

    def reset(self):
        self._finalize()
        self.client.reset_map()
        self.episode_id = None
        self._last_visual = None
        self._last_motion_failed = False
        self._visual_stall_count = 0
        self.stuck_steps = 0
        self._server_busy = False
        self._last_feed_info = {}
        self._frame_save_err = False
        self.calibrator.reset()
        self._oracle_gt = []

    def act(self, observation):
        self._feed_frame(observation)
        action = self._explore_action(observation)
        self._record_and_update(observation, action)
        return action

    # ------------------------------------------------------------------
    # 供子类复用的拆块
    # ------------------------------------------------------------------
    def _feed_frame(self, observation):
        """Pace/feed frames and conservatively detect a blocked forward move."""
        if self.episode_id is None:
            self.episode_id = observation.episode_id
            try:
                self.client.set_episode(self.episode_id)
            except Exception as exc:
                if not self._episode_diag_warned:
                    print(f"[MappingAgent] episode 诊断归档未启用: {exc}")
                    self._episode_diag_warned = True
            self._frame_save_dir = None
            save_root = os.environ.get("NAV_SAVE_FRAMES_DIR")
            if save_root:
                save_root = env_debug_path(
                    "NAV_SAVE_FRAMES_DIR",
                    os.path.join(self.output_dir, "rgb"))
                safe_episode = "".join(
                    ch if ch.isalnum() or ch in "-_." else "_"
                    for ch in str(self.episode_id))[:120] or "unknown"
                self._frame_save_dir = os.path.join(
                    save_root, safe_episode)
                os.makedirs(self._frame_save_dir, exist_ok=True)
                print(f"[MappingAgent] 逐帧 RGB 保存到 {self._frame_save_dir}")

        # pacing：上一轮喂帧时服务端繁忙则先等它空闲，避免关键帧缓冲
        # 被裁剪丢帧。阻塞不消耗 episode 步数预算（步数按 act 次数计）。
        if self._server_busy:
            self.client.wait_idle(timeout=30.0)
        rgb = observation.rgb
        visual = np.asarray(rgb)[::16, ::16, :3].astype(np.int16)
        self._last_motion_failed = False
        if self._last_visual is not None and \
                observation.previous_action == int(Action.MOVE_FORWARD) and \
                visual.shape == self._last_visual.shape:
            delta = float(np.mean(np.abs(visual - self._last_visual)))
            threshold = float(os.environ.get("MAPPING_STUCK_RGB_DELTA", "1.0"))
            # RGB alone is weak evidence in textureless corridors. Require two
            # consecutive static forward observations before discarding a path.
            if delta < threshold:
                self._visual_stall_count += 1
            else:
                self._visual_stall_count = 0
            confirm_steps = max(1, int(os.environ.get(
                "MAPPING_STUCK_CONFIRM_STEPS", "2")))
            self._last_motion_failed = \
                self._visual_stall_count >= confirm_steps
            if self._last_motion_failed and self.calibrator.actions and \
                    self.calibrator.actions[-1] == int(Action.MOVE_FORWARD):
                # 上一步命令未产生视觉运动，不把它当作尺度样本或航位
                # 推算中的真实前进。-1 是内部 no-op，不会发给 benchmark。
                self.calibrator.actions[-1] = -1
        else:
            self._visual_stall_count = 0
        self._last_visual = visual
        # 实验：喂给 SLAM 前中心裁剪，把 hfov 从 90° 收窄到 VGGT
        # 训练分布内的范围（0.5 -> 约 53°）。只影响 SLAM 输入，
        # agent 自身感知与 benchmark 相机配置不变。
        crop_frac = float(os.environ.get("MAPPING_CROP_FRAC", "1.0"))
        if crop_frac < 1.0:
            h, w = rgb.shape[:2]
            ch, cw = int(h * crop_frac), int(w * crop_frac)
            y0, x0 = (h - ch) // 2, (w - cw) // 2
            rgb = rgb[y0:y0 + ch, x0:x0 + cw]
        # 诊断：逐帧保存喂给 SLAM/语义记忆的 RGB（默认与原观测一致）。
        # server 端 feed_frame 也会全量保存；此处为 agent 侧冗余。
        if getattr(self, "_frame_save_dir", None):
            try:
                import cv2
                arr = np.asarray(rgb)
                if arr.ndim == 3 and arr.shape[2] == 3:
                    img = cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)
                elif arr.ndim == 3 and arr.shape[2] == 4:
                    img = cv2.cvtColor(arr, cv2.COLOR_RGBA2BGR)
                else:
                    img = arr
                saved = cv2.imwrite(
                    os.path.join(
                        self._frame_save_dir,
                        f"rgb_{observation.step_count:05d}.jpg"),
                    img, [cv2.IMWRITE_JPEG_QUALITY, 92])
                if not saved:
                    raise OSError("cv2.imwrite returned false")
            except Exception as exc:
                if getattr(self, "_frame_save_err", False) is False:
                    self._frame_save_err = True
                    print(f"[MappingAgent] 逐帧 RGB 保存失败: {exc}")
        info = self.client.feed_frame(rgb)
        self._last_feed_info = dict(info or {})
        self._server_busy = bool(info.get("busy"))
        if observation.step_count % 20 == 0:
            print(f"[MappingAgent] step={observation.step_count} "
                  f"keyframe={info.get('is_keyframe')} "
                  f"queued={info.get('queued_keyframes')} "
                  f"busy={info.get('busy')}")
        return info

    def _explore_action(self, observation):
        """简单随机探索：默认前进，偶发转向；检测卡住（位置没动）则转向。"""
        if self._last_motion_failed:
            self.stuck_steps += 1
        else:
            self.stuck_steps = 0

        if self.stuck_steps >= 2:
            return int(self.rng.choice([Action.TURN_LEFT, Action.TURN_RIGHT]))
        # 转向概率可调：MAPPING_TURN_PROB 默认 0.3（左右各半）。
        # 平滑探索实验设为 0.05 左右，验证大旋转对 SLAM 的影响。
        turn_prob = float(os.environ.get("MAPPING_TURN_PROB", "0.3"))
        r = self.rng.random()
        if r >= turn_prob:
            return int(Action.MOVE_FORWARD)
        if r < turn_prob / 2:
            return int(Action.TURN_LEFT)
        return int(Action.TURN_RIGHT)

    def _record_and_update(self, observation, action):
        """记录动作 + 定期更新在线尺度估计（滑动窗口，带 pacing 时位姿基本最新）。"""
        self._trace_action(observation, action)
        self.calibrator.record_action(action)
        if self.oracle_geometry:
            gps = getattr(observation, "gps", None)
            self._oracle_gt.append(
                None if gps is None else np.asarray(gps, dtype=np.float64))
        if observation.step_count % 10 == 0 and observation.step_count > 0:
            poses, frame_ids = self.client.get_all_poses()
            if self.oracle_geometry:
                scale = self._oracle_scale_update(poses, frame_ids)
                if scale is not None:
                    print(f"[MappingAgent] step={observation.step_count} "
                          f"ORACLE 尺度={scale:.4f} m/unit（消融专用）")
            else:
                scale = self.calibrator.update(poses, frame_ids)
                if scale is not None:
                    print(f"[MappingAgent] step={observation.step_count} "
                          f"在线尺度估计={scale:.4f} m/unit")

    def _trace_action(self, observation, action):
        """Record every executed benchmark action and its decision context."""
        try:
            action_name = Action(int(action)).name
        except Exception:
            action_name = str(action)
        previous = getattr(observation, "previous_action", None)
        try:
            previous_name = Action(int(previous)).name
        except Exception:
            previous_name = None
        feed = dict(getattr(self, "_last_feed_info", {}) or {})
        record = {
            "t": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "episode": str(getattr(observation, "episode_id", self.episode_id)),
            "step": int(observation.step_count),
            "goal_text": str(getattr(observation, "goal_text", "") or ""),
            "actual_action": {"id": int(action), "name": action_name},
            "previous_action": {"id": previous, "name": previous_name},
            "agent_mode": getattr(self, "mode", None),
            "target_instance_id": getattr(self, "target_instance_id", None),
            "target_candidate_id": getattr(self, "target_candidate_id", None),
            "adjusting": bool(getattr(self, "_adjusting", False)),
            "scanning": bool(getattr(self, "_scanning", False)),
            "last_motion_failed": bool(self._last_motion_failed),
            "mapping_frame_id": feed.get("frame_id"),
            "mapping": {
                "is_keyframe": feed.get("is_keyframe"),
                "queued_keyframes": feed.get("queued_keyframes"),
                "busy": feed.get("busy"),
            },
            "last_decision": getattr(self, "_last_decision_output", None),
        }
        try:
            os.makedirs(os.path.dirname(self._action_trace_path) or ".",
                        exist_ok=True)
            with open(self._action_trace_path, "a", encoding="utf-8") as fp:
                fp.write(json.dumps(
                    record, ensure_ascii=False, default=str) + "\n")
        except OSError as exc:
            if not self._trace_write_warned:
                print(f"[MappingAgent] action trace 写入失败: {exc}")
                self._trace_write_warned = True

    def _oracle_scale_update(self, poses, frame_ids):
        """oracle 消融尺度：分子用 GT 位移（米）替换动作步长假设。

        结构与 ScaleCalibrator.update 相同（相邻关键帧 SLAM 位移做
        分母、滑动窗口中位数），但位移真值来自 observation.gps 轨迹，
        不受撞墙/打滑影响。只写入 calibrator.scale_history，下游
        current_scale() 消费方式不变。
        """
        if poses is None or len(poses) < 2:
            return self.calibrator.current_scale()
        order = np.argsort(frame_ids)
        frame_ids = np.asarray(frame_ids)[order]
        positions = np.asarray(poses)[order][:, 0:3, 3]
        ratios = []
        for i in range(1, len(positions)):
            f_a, f_b = int(frame_ids[i - 1]), int(frame_ids[i])
            lo, hi = f_a - 1, f_b - 1
            if lo < 0 or hi >= len(self._oracle_gt) or hi <= lo:
                continue
            # 两端关键帧的观测位置都需要保留，右端索引是闭区间。
            seg = self._oracle_gt[lo:hi + 1]
            if not seg or any(g is None for g in seg):
                continue
            gt_dist = float(np.linalg.norm(seg[-1] - seg[0]))
            slam_dist = float(np.linalg.norm(positions[i] - positions[i - 1]))
            if gt_dist < 1e-4 or slam_dist < 1e-6:
                continue
            ratios.append(gt_dist / slam_dist)
        if len(ratios) < self.calibrator.min_samples:
            return self.calibrator.current_scale()
        med = float(np.median(np.asarray(ratios[-self.calibrator.window:])))
        self.calibrator.scale_history.append((len(self.calibrator.actions),
                                              med))
        return med

    # ------------------------------------------------------------------
    def _finalize(self):
        if self.episode_id is None:
            return
        episode = self.episode_id
        self.episode_id = None
        try:
            # flush_map 同时等待在途子图并提交未满子图的尾帧。
            self.client.flush_map()
            poses, frame_ids = self.client.get_all_poses()
        except Exception as exc:
            print(f"[MappingAgent] episode {episode}: 收尾失败: {exc}")
            return
        if poses is None or len(poses) < 1:
            print(f"[MappingAgent] episode {episode}: SLAM 位姿不足，跳过保存")
            return
        slam_xyz = poses[:, 0:3, 3]
        cal_scale = self.calibrator.current_scale()

        safe_episode = "".join(
            ch if ch.isalnum() or ch in "-_." else "_"
            for ch in str(episode))[:120] or "unknown"
        out = os.path.join(self.output_dir, f"traj_{safe_episode}.npz")
        np.savez(out, slam_xyz=slam_xyz, frame_ids=frame_ids,
                 actions=np.asarray(self.calibrator.actions),
                 calibrator_scale=cal_scale if cal_scale else np.nan,
                 calibrator_history=np.array(
                     [h[1] for h in self.calibrator.scale_history]))
        print(f"[MappingAgent] episode {episode}: keyframes={len(poses)} -> {out}")
        if cal_scale:
            print(f"[MappingAgent] 在线尺度标定={cal_scale:.4f} m/unit")


if __name__ == "__main__":
    # 冒烟测试：不依赖 habitat，直接用渐变图验证 server/client 通路
    client = MappingClient()
    client.reset_map()
    for i in range(40):
        img = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
        print(client.feed_frame(img))
    print(client.get_state())
    client.close()
